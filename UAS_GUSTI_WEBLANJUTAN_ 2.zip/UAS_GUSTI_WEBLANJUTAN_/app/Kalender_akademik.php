<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Kalender_akademik extends Model
{
    protected $table = 'kalender_akademik';
    protected $primaryKey = 'kalender_akademik_id';
}
